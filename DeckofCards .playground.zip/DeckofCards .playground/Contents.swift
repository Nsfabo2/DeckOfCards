import UIKit

enum Colors:String{
    case ColorOne = "Red"
    case ColorTwo = "Blue"
    case ColorThree = "Green"
}
//1
struct Card{
    var Color: Colors
    var Roll: Int
    
    init(Color: Colors){
        self.Color = Color
        switch(Color){
        case .ColorOne:
            Roll = Int.random(in: 1...2)
        case .ColorTwo:
            Roll = Int.random(in: 3...4)
        case .ColorThree:
            Roll = Int.random(in: 5...6)
        }
    }
}
//2
class Deck{
    var cards: [Card] = []
    
    init(){
        for i in 1...30{
            if i <= 10{
                cards.append(Card(Color: Colors.ColorOne))
            }
            else if i <= 20{
                cards.append(Card(Color: Colors.ColorTwo))
            }
            else{
                cards.append(Card(Color: Colors.ColorThree))
            }
        }
}
    
    func topmost() -> Card {
        return cards.removeLast()
    }
    
    func isEmpty() -> Bool{
        return cards.isEmpty
    }
    
    func shuffle(){
       cards.shuffle()
    }
}//end class

class Player{
    var name: String = ""
    var hand: [Card] = []
    
    func draw(deck: Deck) -> Card{
                let card = deck.topmost()
                hand.append(card)
                return card
        }
        
        func rollDice() -> Int{
            return Int.random(in: 1...6)
        }
        
        func matchingCards(color: String, roll: Int) -> Int{
            var Counter = 0
            for card in hand{
                if card.Roll == roll && card.Color.rawValue == color{
                    Counter += 1
                }
            }
            return Counter
        }
    
}//end class




